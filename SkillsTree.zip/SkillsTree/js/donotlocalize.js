var i = 0;
var t = 0;
var nlclass = "druid";
var nlclassPatch = "druid";

nltree[i] = "Balance"; i++;
nltree[i] = "Feral Combat"; i++;
nltree[i] = "Restoration"; i++;

i = 0;

nltalent[i] = ["Starlight Wrath"]; i++;
nltalent[i] = ["Genesis"]; i++;
nltalent[i] = ["Moonglow"]; i++;
nltalent[i] = ["Natures Mastery"]; i++;
nltalent[i] = ["Improved Moonfire"]; i++;
nltalent[i] = ["Brambles"]; i++;
nltalent[i] = ["Natures Grace"]; i++;
nltalent[i] = ["Natures Splendor"]; i++;
nltalent[i] = ["Natures Reach"]; i++;
nltalent[i] = ["Vengeance"]; i++;
nltalent[i] = ["Celestial Focus"]; i++;
nltalent[i] = ["Lunar Guidance"]; i++;
nltalent[i] = ["Insect Swarm"]; i++;
nltalent[i] = ["Improved Insect Swarm"]; i++;
nltalent[i] = ["Dreamstate"]; i++;
nltalent[i] = ["Moonfury"]; i++;
nltalent[i] = ["Balance of Power"]; i++;
nltalent[i] = ["Moonkin Form"]; i++;
nltalent[i] = ["Improved Moonkin Form"]; i++;
nltalent[i] = ["Improved Faerie Fire"]; i++;
nltalent[i] = ["Owlkin Frenzy"]; i++;
nltalent[i] = ["Wrath of Cenarius"]; i++;
nltalent[i] = ["Eclipse"]; i++;
nltalent[i] = ["Typhoon"]; i++;
nltalent[i] = ["Force of Nature"]; i++;
nltalent[i] = ["Gale Winds"]; i++;
nltalent[i] = ["Earth and Moon"]; i++;
nltalent[i] = ["Starfall"]; i++;
treeStartStop[t] = i -1;
t++;

//feral talents
nltalent[i] = ["Ferocity"]; i++;
nltalent[i] = ["Feral Aggression"]; i++;
nltalent[i] = ["Feral Instinct"]; i++;
nltalent[i] = ["Savage Fury"]; i++;
nltalent[i] = ["Thick Hide"]; i++;
nltalent[i] = ["Feral Swiftness"]; i++;
nltalent[i] = ["Survival Instincts"]; i++;
nltalent[i] = ["Sharpened Claws"]; i++;
nltalent[i] = ["Shredding Attacks"]; i++;
nltalent[i] = ["Predatory Strikes"]; i++;
nltalent[i] = ["Primal Fury"]; i++;
nltalent[i] = ["Primal Precision"]; i++;
nltalent[i] = ["Brutal Impact"]; i++;
nltalent[i] = ["Feral Charge"]; i++;
nltalent[i] = ["Nurturing Instinct"]; i++;
nltalent[i] = ["Natural Reaction"]; i++
nltalent[i] = ["Heart of the Wild"]; i++;
nltalent[i] = ["Survival of the Fittest"]; i++;
nltalent[i] = ["Leader of the Pack"]; i++;
nltalent[i] = ["Improved Leader of the Pack"]; i++;
nltalent[i] = ["Primal Tenacity"]; i++;
nltalent[i] = ["Protector of the Pack"]; i++;
nltalent[i] = ["Predatory Instincts"]; i++;
nltalent[i] = ["Infected Wounds"]; i++;
nltalent[i] = ["King of the Jungle"]; i++;
nltalent[i] = ["Mangle"]; i++;
nltalent[i] = ["Improved Mangle"]; i++;
nltalent[i] = ["Rend and Tear"]; i++;
nltalent[i] = ["Primal Gore"]; i++;
nltalent[i] = ["Berserk"]; i++;

treeStartStop[t] = i -1;
t++;

//restoration talents

nltalent[i] = ["Improved Mark of the Wild"]; i++;
nltalent[i] = ["Natures Focus"]; i++;
nltalent[i] = ["Furor"]; i++;
nltalent[i] = ["Naturalist"]; i++;
nltalent[i] = ["Subtlety"]; i++;
nltalent[i] = ["Natural Shapeshifter"]; i++;
nltalent[i] = ["Intensity"]; i++;
nltalent[i] = ["Omen of Clarity"]; i++;
nltalent[i] = ["Master Shapeshifter"]; i++;
nltalent[i] = ["Tranquil Spirit"]; i++;
nltalent[i] = ["Improved Rejuvenation"]; i++;
nltalent[i] = ["Natures Swiftness"]; i++;
nltalent[i] = ["Gift of Nature"]; i++;
nltalent[i] = ["Improved Tranquility"]; i++;
nltalent[i] = ["Empowered Touch"]; i++;
nltalent[i] = ["Natures Bounty"]; i++;
nltalent[i] = ["Living Spirit"]; i++;
nltalent[i] = ["Swiftmend"]; i++;
nltalent[i] = ["Natural Perfection"]; i++;
nltalent[i] = ["Empowered Rejuvenation"]; i++;
nltalent[i] = ["Living Seed"]; i++;
nltalent[i] = ["Revitalize"]; i++;
nltalent[i] = ["Tree of Life"]; i++;
nltalent[i] = ["Improved Tree of Life"]; i++;
nltalent[i] = ["Improved Barkskin"]; i++;
nltalent[i] = ["Gift of the Earthmother"]; i++;
nltalent[i] = ["Wild Growth"]; i++;

treeStartStop[t] = i -1;
t++;
jsLoaded=true;//needed for ajax script loading
