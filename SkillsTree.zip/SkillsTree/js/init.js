﻿var talent = new Array();
var rank = new Array();
var tree = new Array();
var nltree = new Array();
var nltalent = new Array();
var rankBottom = new Array();
var minLevel = new Array();
var hasDependentTalents = new Array();
var treeStartStop = new Array();
var rankTop = new Array();
var pointsTree = new Array();
var maxTierArray = new Array();
//var snlclass="druid";
maxTierArray[0] = 1;
maxTierArray[1] = 1;
maxTierArray[2] = 1;
var template = new Array();
var levelMax = 80;
var levelMin = 10;
var tierNum = 12;
var rankPoints = levelMax - levelMin + 1;
var rankPointsMax = rankPoints;
var levelCurrent = levelMax;
var theRequiredLevel = levelMin - 1;
//////////
var dataarray = new Array();

function getdata(fs,par)
{
var tempcl=fs;
if(tempcl.indexOf(par)>-1) 
{
var tempcl=tempcl.slice(tempcl.indexOf(par)+par.length);
   if(tempcl.indexOf("&")>-1) 
	  { 
	    tempcl=tempcl.slice(0,tempcl.indexOf("&"));
	  }
}
else tempcl="none";
return tempcl;
}

function classfind()
{
if (variableIsSite) query = window.location.search.substring(1);
var language=query;
language=getdata(query,"lan=");
if (language=="none") language="ru";
var snlclass=query;
snlclass=getdata(query,"class=");
if (snlclass=="none") snlclass="druid";
query=getdata(query,"tal=");
if (query=="none") query="";
dataarray[1]=snlclass;
dataarray[2]=language;
return dataarray;
}

jsLoaded=true;