﻿var pixelGif = "img1/pixel.gif";
var textLevelRequired = "Требуется уровень ";
var textPointsLeft = "Осталось очков:";
var textPointsSpent = "Потрачено очков:";
var textPoint = "очко";
var textPoints = "очк.";
var textColon = ":";
var textLeftClick = "Щелкните левой кнопкой мыши, чтобы обучиться"
var textRightClick = "Щелкните правой кнопкой мыши, чтобы разучиться"
var textRankColon = "Уровень:"
var textToSave = "Чтобы сохранить шаблон, скопируйте этот адрес:";
var textNextRank = "Следующий уровень:";
var requiresRequires = "Требуется";
var requiresPointsIn = "очк. в ";
var requiresTalents = "Таланты";

function getStringRequires(requirementPoints, requirementName) {
	theS = "s";
	if (requirementPoints == 1)
		theS = "";
	var theString = 'Требуется '+ requirementPoints +' очк.'+ theS +' в '+ requirementName;
	return theString;
}

function getStringRequiresTalents(requirementPoints, requirementName) {
	var theString = 'Требуется '+ requirementPoints +' очк. в талантах '+ requirementName;
	return theString
}

function printableVersion() {

	var levelRequired = rankPointsMax - rankPoints + levelMin - 1;	
	var pointsRequired = rankPointsMax - rankPoints;

    var w = window.open("","","resizable=1,toolbar=1,width=800,height=600,status=1,scrollbars=1,menubar=1, screenX=100, screenY=100, left=100, top=100");
	w.document.write("<html><body bgcolor=ffffff><span style = 'font-family: verdana; font-size = 10pt'>");
	w.document.write("<h3>"+ className + "</h3>Требуется уровень: <b>"+ levelRequired +"</b><br>Необходимо потратить очков: <b>"+ pointsRequired +"</b>");	
	w.document.write("<table border=0 cellpadding=0 cellspacing=0 width=100%>");

	
	if (pointsRequired == 0) {
		w.document.write("<br>&nbsp;&nbsp;&nbsp;Не тратьте бумагу зря!");
	}
	
	var rightTreeID = -1;
	for (var blah = 0; blah != talent.length; blah++){
		if (talent[blah][0] != rightTreeID) {
			rightTreeID = talent[blah][0];

			if (pointsTree[rightTreeID] != 0)
				w.document.write("<tr><td width=100%><br><b><u>"+tree[rightTreeID]+" Таланты</u> - </b></span><span class=mySmall>&nbsp;<span id='"+ tree[rightTreeID] +"Очки' class=mySmall>"+ pointsTree[rightTreeID] +"</span> очк.<br><br></td></tr>");
		}

		if (rankTop[blah][0] != 0) {
			w.document.write("<tr><td colspan=2 style = \"padding-left:18px\"><span id='displayRight"+ blah +"'><li><b>"+ talent[blah][1] +"</b> - rank <span id='modifyRankRight"+ blah +"' class=mySmallBlack>"+ rankTop[blah][0] +"</span>/<span class=mySmallBlack>"+ talent[blah][2] +"</span><br></span></td></tr>");
			//w.document.write("<tr><td colspan=2 style = \"padding-left:36px\">"+ rankTop[blah][1] +"</td></tr>");
		}
	}

	w.document.write("</table>");	
	w.document.write("</font></body></html>");
	w.document.close();
	
}

